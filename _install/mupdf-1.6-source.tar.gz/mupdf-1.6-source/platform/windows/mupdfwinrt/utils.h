#pragma once

#include "Windows.h"
using namespace Platform;

String^ char_to_String(const char *char_in);
char* String_to_char(String^ text);
