#include "pch.h"
#include "ContentItem.h"

using namespace mupdfwinrt;

ContentItem::ContentItem(void)
{
	StringOrig = nullptr;
	StringMargin = nullptr;
	Page = 0;
}
