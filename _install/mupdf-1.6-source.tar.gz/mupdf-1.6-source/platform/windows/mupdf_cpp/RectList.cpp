#include "pch.h"
#include "RectList.h"

namespace mupdf_cpp
{
	RectList::RectList(void)
	{
	}
}
