Note building the projects in this solution requires VS 2013
To build the installer projects you will need the extension:

Microsoft Visual Studio Installer Projects

located at

http://visualstudiogallery.msdn.microsoft.com/9abe329c-9bba-44a1-be59-0fbf6151054d