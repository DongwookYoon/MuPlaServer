/* If you want to build the library manually without using
 * 'configure' or 'CMake'
 * then copy this file
 * 'opj_config.h.cmake.in'
 *	to
 * 'opj_config.h'
 *
 * Open 'opj_config.h' and change the file contents
 * if you want to define something because you know you have
 * BOTH installed the library AND the header file(s).
 * Then e.g. write
#define HAVE_LIBPNG 1
 *
 *
 * The file 'opj_config.h' will be included in some source files.
 * ==== YOU CAN NOT COMPILE WITHOUT IT. ====
 * === DO NOT FORGET TO CHANGE 'config.nix' APPROPRIATELY. ====
*/



